class InterviewSession {
  final String question;
  final String answer;
  final String feedback;

  InterviewSession({required this.question, required this.answer, required this.feedback});
}