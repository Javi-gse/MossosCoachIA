class QuestionBank {
  static List<String> getQuestions({required int age}) {
    if (age < 25) {
      return [
        "Com gestiones la disciplina en la teva vida quotidiana?",
        "Què esperes aprendre com a Mosso jove?",
        "Has tingut experiències de lideratge a l'escola o universitat?",
      ];
    } else if (age < 35) {
      return [
        "Quin valor afegeixes al cos amb la teva experiència?",
        "Com ha evolucionat la teva vocació amb els anys?",
        "Explica una situació laboral on vas actuar amb responsabilitat.",
      ];
    } else {
      return [
        "Com mantens la teva motivació i energia en entorns exigents?",
        "Quins valors familiars portes a la teva feina?",
        "Has assumit rols de mentoratge o supervisió anteriorment?",
      ];
    }
  }
}