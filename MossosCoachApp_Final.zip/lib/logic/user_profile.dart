class UserProfile {
  final String name;
  final int age;
  final String style;
  final int duration;

  UserProfile({
    required this.name,
    required this.age,
    required this.style,
    required this.duration,
  });
}