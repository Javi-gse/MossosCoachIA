import 'package:flutter/material.dart';

class InterviewerAvatar extends StatelessWidget {
  final String style;

  InterviewerAvatar({required this.style});

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: 36,
      backgroundColor: style == "agressiu" ? Colors.red : Colors.green,
      child: Icon(
        style == "agressiu" ? Icons.warning : Icons.person,
        color: Colors.white,
        size: 36,
      ),
    );
  }
}