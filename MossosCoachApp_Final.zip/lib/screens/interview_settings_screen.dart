import 'package:flutter/material.dart';
import 'interview_screen.dart';
import '../logic/user_profile.dart';

class InterviewSettingsScreen extends StatefulWidget {
  final String userName;
  final int userAge;

  InterviewSettingsScreen({required this.userName, required this.userAge});

  @override
  _InterviewSettingsScreenState createState() => _InterviewSettingsScreenState();
}

class _InterviewSettingsScreenState extends State<InterviewSettingsScreen> {
  String _style = "amable";
  int _duration = 20;

  void _startInterview() {
    final profile = UserProfile(
      name: widget.userName,
      age: widget.userAge,
      style: _style,
      duration: _duration,
    );

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => InterviewScreen(profile: profile)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Configuració de l'entrevista")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: _style,
              onChanged: (value) => setState(() => _style = value ?? "amable"),
              items: [
                DropdownMenuItem(child: Text("Amable"), value: "amable"),
                DropdownMenuItem(child: Text("Agressiu"), value: "agressiu"),
              ],
              decoration: InputDecoration(labelText: "Estil de l'entrevistador"),
            ),
            DropdownButtonFormField<int>(
              value: _duration,
              onChanged: (value) => setState(() => _duration = value ?? 20),
              items: [20, 30, 40, 60]
                  .map((e) => DropdownMenuItem(child: Text("$e minuts"), value: e))
                  .toList(),
              decoration: InputDecoration(labelText: "Duració"),
            ),
            SizedBox(height: 20),
            ElevatedButton(onPressed: _startInterview, child: Text("Comença entrevista")),
          ],
        ),
      ),
    );
  }
}