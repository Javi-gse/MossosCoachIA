import 'package:flutter/material.dart';
import 'interview_settings_screen.dart';
import '../logic/user_profile.dart';

class RegistrationScreen extends StatefulWidget {
  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _nameController = TextEditingController();
  final _ageController = TextEditingController();

  void _continue() {
    final name = _nameController.text.trim();
    final age = int.tryParse(_ageController.text) ?? 0;

    if (name.isNotEmpty && age > 0) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => InterviewSettingsScreen(userName: name, userAge: age),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Registre")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _nameController, decoration: InputDecoration(labelText: "Nom")),
            TextField(controller: _ageController, decoration: InputDecoration(labelText: "Edat"), keyboardType: TextInputType.number),
            SizedBox(height: 20),
            ElevatedButton(onPressed: _continue, child: Text("Continua")),
          ],
        ),
      ),
    );
  }
}